/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.amickom.service.exception;

/**
 *
 * @author GRUPO HERA HP2
 */
public class RefaccionariaException extends Exception {

    public RefaccionariaException() {
    }

    public RefaccionariaException(String message) {
        super(message);
    }

    public RefaccionariaException(Throwable cause) {
        super(cause);
    }

    public RefaccionariaException(String message, Throwable cause) {
        super(message, cause);
    }

    public RefaccionariaException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
    
    
    
}
