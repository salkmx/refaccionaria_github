/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.amickom.autopartsswing.listener;

import com.amickom.autopartdao.dto.PedidoProducto;
import com.amickom.autopartdao.dto.Productos;
import com.amickom.autopartsswing.Utils;
import com.amickom.autopartsswing.operacion.OperacionPanel;
import com.amickom.service.exception.RefaccionariaException;
import javax.swing.JFrame;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;
import javax.swing.table.TableModel;
import org.apache.log4j.Logger;

/**
 *
 * @author david
 */
/**
 * Clase que verifica cuando una celda es 
 * seleccionada por un usuario
 */
public class SeleccionModelListener implements TableModelListener {

    private static Logger logger = Logger.getLogger(SeleccionModelListener.class);
    private TableModel model;
    private OperacionPanel panel;

    /**
     * Constructor por default
     */
    public SeleccionModelListener(
            TableModel model, OperacionPanel panel) {
        this.model = model;
        this.panel = panel;
    }

    @Override
    public void tableChanged(TableModelEvent e) {
        StringBuilder sb = new StringBuilder();
        switch (e.getType()) {
            case TableModelEvent.UPDATE:
                if (e.getColumn() == 0) {
                    Integer indice = e.getFirstRow();
                    logger.debug("Actualizando el valor de " + e.getSource().toString() + " " + indice + " " + e.getLastRow());
                    Boolean estado = (Boolean) model.getValueAt(indice, 0);
                    PedidoProducto pedido = new PedidoProducto();
                    Productos prod = new Productos();
                    prod.setCodigo((String) model.getValueAt(indice, 1));
                    prod.setDescripcion((String) model.getValueAt(indice, 2));
                    prod.setPrecio(((Double) model.getValueAt(indice, 3)));
                    prod.setMarca((String) model.getValueAt(indice, 4));
                    pedido.setProductos(prod);
                    if (model.getValueAt(indice, 5) == null) {
                        sb.append("Debe seleccionar la utilidad \n");
                    } else {
                        pedido.setUtilidad((Double) model.getValueAt(indice, 5));
                    }
                    if (model.getValueAt(indice, 6) == null) {
                        sb.append("Debe seleccionar la cantidad \n");
                    } else {
                        pedido.setCantidad((Double) model.getValueAt(indice, 6));
                    }
                    if (estado.booleanValue() == true) {
                        try {
                            logger.debug("Insertando producto " + prod.toString());
                            if (sb.toString().trim().equals("")) {
                                if(panel.productosService.insertaTemp(pedido)) {
                                    Utils.mensajeExito("Producto agregado al pedido", (JFrame) panel.getParent().
                                        getParent().getParent().
                                        getParent().getParent());
                                }
                                else {
                                    Utils.mensajeError("Error al agregar el  producto al pedido", (JFrame) panel.getParent().
                                        getParent().getParent().
                                        getParent().getParent());
                                }
                            } else {
                                Utils.mensajeError(sb.toString(), (JFrame) panel.getParent().
                                        getParent().getParent().
                                        getParent().getParent());
                            }

                        } catch (RefaccionariaException ex) {
                            logger.error("El producto no se inserto " + prod.toString());
                        }
                    } else {
                        try {
                            logger.debug("Eliminando producto " + prod.toString());
                            if (panel.productosService.deleteTemp(pedido)) {
                                model.setValueAt(null, indice, 5);
                                model.setValueAt(null, indice, 6);
                                Utils.confirmaCancelacion((JFrame) panel.getParent().
                                        getParent().getParent().
                                        getParent().getParent(), 
                                        "Desea eliminar el producto del pedido");
                            }
                        } catch (RefaccionariaException ex) {
                            logger.error("El producto no se Elimino " + prod.toString());
                        }

                    }
                }
                break;
            default:
                break;
        }
    }
}
