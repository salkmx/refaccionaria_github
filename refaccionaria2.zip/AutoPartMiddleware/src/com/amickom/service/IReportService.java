/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.amickom.service;

import com.amickom.autopartdao.dto.NotaRemisionDTO;
import com.amickom.service.exception.RefaccionariaException;

/**
 *
 * @author david
 */
public interface IReportService {
    
    /**
     * Método que genera la nota de remision para su posterior presentación en la vista
     * @param remisionDTO objeto con los datos de la nota de remisión
     * @return String con la ruta de generación de la nota de remisión
     * @throws RefaccionariaException en caso de cualquier excepción 
     */
    public String generaNotaRemision(NotaRemisionDTO remisionDTO) throws RefaccionariaException;
    
}
