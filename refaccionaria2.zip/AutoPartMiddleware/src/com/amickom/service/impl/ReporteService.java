/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.amickom.service.impl;

import com.amickom.autopartdao.dto.Cliente;
import com.amickom.autopartdao.dto.NotaRemisionDTO;
import com.amickom.autopartdao.dto.Pedido;
import com.amickom.autopartdao.dto.PedidoProducto;
import com.amickom.service.IReportService;
import com.amickom.service.exception.RefaccionariaException;
import com.amickom.service.util.Formatter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperRunManager;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

/**
 *
 * @author david
 */
@Service("reporteService")
public class ReporteService implements IReportService {

    private static Logger log = Logger.getLogger(ProveedorService.class);

    @Override
    public String generaNotaRemision(NotaRemisionDTO remisionDTO)
            throws RefaccionariaException {
        log.debug("Iniciando la generación de la nota de remisión: ");
        List<PedidoProducto> pedidos = remisionDTO.getPedidoproducto();
        List<HashMap<String, String>> data = new ArrayList<HashMap<String, String>>();
        for (PedidoProducto producto : pedidos) {
            HashMap<String, String> fields = new HashMap<String, String>();
            fields.put("cantidad", Formatter.formatMonto(producto.getCantidad()));
            fields.put("codigo", producto.getProductos().getCodigo());
            fields.put("descripcion", producto.getProductos().getDescripcion());
            double precioTotalProducto = producto.getProductos().getPrecio()
                    + producto.getUtilidad()
                    * producto.getCantidad();
            fields.put("preciounitario", Formatter.formatMonto(producto.getProductos().getPrecio()));
            fields.put("preciototal", Formatter.formatMonto(precioTotalProducto));
            data.add(fields);
        }
        Pedido pedido = remisionDTO.getPedido();
        Cliente cliente = remisionDTO.getCliente();
        HashMap<String, String> parameters = new HashMap<String, String>();
        parameters.put("NOMBRE_USUARIO", "Artemio Vergara Tolentino");
        parameters.put("FECHA_CREACION", Formatter.formatFechaCorta(
                Calendar.getInstance().getTime()));
        parameters.put("PEDIDO", String.valueOf(pedido.getId()));
        parameters.put("NOMBRE_CLIENTE", cliente.getNombre());
        parameters.put("DIRECCION_CLIENTE", cliente.getDireccion());
        parameters.put("TELEFONO_CELULAR", cliente.getTelefono());//Arreglar bd para tener el telefono celular
        parameters.put("CP_CLIENTE", cliente.getRfc());//Arreglar bd para tener el cp_cliente
        parameters.put("CIUDAD_CLIENTE", cliente.getEmail()); //Arreglar bd para tener la ciudad del cliente        
        parameters.put("RFC_CLIENTE", cliente.getRfc());
        parameters.put("NUMERO_USUARIO", "1");
        parameters.put("PRECIO_LETRA", "No habilitado por ahora");
        parameters.put("SUBTOTAL_PEDIDO", Formatter.formatMonto(remisionDTO.getSubtotal()));
        parameters.put("TOTAL_PEDIDO", Formatter.formatMonto(remisionDTO.getTotal()));
        OutputStream os = null;
         File reporte = null;
        try {
            JRDataSource datasource = new JRBeanCollectionDataSource(
                    data);
            InputStream jasper = ReporteService.class.getClassLoader().getResourceAsStream(
                    "com/amickom/reportes/casa.jasper");
            byte[] report = JasperRunManager.runReportToPdf(jasper,
                    parameters, datasource);
            reporte = new File("/notaremision" + pedido.getId() + ".pdf");
            os = new FileOutputStream(reporte);
            os.write(report);
        } catch (JRException e) {
            log.error("Error al generar el reporte " + e.getMessage(), e);
        }
        catch (FileNotFoundException e) {
            log.error("Error al generar el reporte " + e.getMessage(), e);
        }
        catch (IOException e) {
            log.error("Error al generar el reporte " + e.getMessage(), e);
        }
        finally {
            if (os != null) {
                try {
                    os.close();
                } catch (IOException ex) {
                    log.error("Error al generar el reporte " + 
                            ex.getMessage(), ex);
                }
            }
        }
        return reporte.getAbsolutePath();
    }
}
