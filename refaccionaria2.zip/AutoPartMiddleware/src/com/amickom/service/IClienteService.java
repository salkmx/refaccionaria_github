/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.amickom.service;

import com.amickom.autopartdao.dto.Cliente;
import com.amickom.service.exception.RefaccionariaException;
import com.amickom.service.util.ComboModelCliente;

/**
 *
 * @author GRUPO HERA HP2
 */
public interface IClienteService {
    
    /**
     * Realiza el alta de un cliente
     * @param cliente cliente que va a ser dado de alta
     * @return true en caso de ser  correcto, false en caso contrario
     * @throws RefaccionariaException en caso de cualquier excepción 
     */
    public boolean insertaCliente(Cliente cliente) throws RefaccionariaException;
    
    /**
     * Obtiene el modelo de clientes para el combobox
     * @return ComboModelCliente modelo de datos para el combobox de clientes
     * @throws RefaccionariaException  en caso de cualquier excepción
     */
    public ComboModelCliente obtieneModelCliente() throws RefaccionariaException;
 
    
}
