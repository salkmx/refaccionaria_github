/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.amickom.service;

import com.amickom.autopartdao.dto.PedidoProducto;
import com.amickom.service.exception.RefaccionariaException;
import com.amickom.service.util.ComboModelMarca;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author david
 */
public interface IProductoService {

    /**
     * Obtiene ComboModelMarca para el combo de marcas
     * @return ComboModelMarca modelo con las marcas que existen en el 
     * la tabla de productos
     */
    public ComboModelMarca obtieneMarcas() throws RefaccionariaException;

    /**
     * Obtiene el modelo para que se seleccione el valor de los
     * productos que se van a presentar en la pantalla de pedido
     * @param marca marca de la cual se van a obtener los productos en 
     * caso de ir null todas
     * @param codigo codigo del producto a buscar en caso de ir null
     * todos
     * @return ProductoTableModel modelo de datos a mostrar
     * @throws RefaccionariaException en caso de cualquier excepción 
     */
    public DefaultTableModel obtieneProductos(String marca, String codigo) throws RefaccionariaException;

    /**
     * Obtiene el modelo para que se seleccione el valor de los
     * productos que se van a presentar en la pantalla de pedido
     * @param productos lista con los productos seleccionados
     * @return ProductoTableModel modelo de datos a mostrar
     * @throws RefaccionariaException en caso de cualquier excepción 
     */
    public DefaultTableModel obtieneProductosTemp() throws RefaccionariaException;

    /**
     * Inserta un producto en la tabla temporal de productos pedidos
     * @param producto producto que va a hacer agregado a la lista
     * @return true si se inserto correctamente false en caso contrario
     * @throws RefaccionariaException en caso de cualquier excepción 
     */
    public boolean insertaTemp(PedidoProducto producto) throws RefaccionariaException;

    /**
     * Elimina un registro de la tabla temporal de productos pedidos
     * @param producto producto que va a hacer agregado a la lista
     * @return true si se elimino correctamente false en caso contrario
     * @throws RefaccionariaException en caso de cualquier excepción 
     */
    public boolean deleteTemp(PedidoProducto producto) throws RefaccionariaException;

    /**
     * Borra la tabla temporal de 
     * @return true si se inserto correctamente false en caso contrario
     * @throws RefaccionariaException en caso de cualquier excepción 
     */
    public boolean deleteAllTemp() throws RefaccionariaException;
}
