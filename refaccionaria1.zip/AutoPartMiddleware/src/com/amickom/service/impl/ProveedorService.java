/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.amickom.service.impl;

import com.amickom.autopartdao.dao.ArchivosDao;
import com.amickom.autopartdao.dao.ExcelDAO;
import com.amickom.autopartdao.dao.ProductosDao;
import com.amickom.autopartdao.dao.ProveedorDao;
import com.amickom.autopartdao.dto.Productos;
import com.amickom.autopartdao.dto.Proveedor;
import com.amickom.autopartdao.dto.ProveedorPk;
import com.amickom.autopartdao.exceptions.ProveedorDaoException;
import com.amickom.service.IProveedorService;
import com.amickom.service.exception.RefaccionariaException;
import com.amickom.service.util.ComboModelProveedor;
import java.util.List;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

/**
 *
 * @author GRUPO HERA HP2
 */
@Service("proveedorService")
public class ProveedorService implements IProveedorService {

    @Autowired
    @Qualifier("ProductosDao")
    private ProductosDao prodDAO;
    @Autowired
    @Qualifier("ExcelDAO")
    private ExcelDAO excelDAO;
    @Autowired
    @Qualifier("ProveedorDao")
    private ProveedorDao dao;
    @Autowired
    @Qualifier("ArchivosDao")
    private ArchivosDao daoArchivo;
    private static Logger logger = Logger.getLogger(ProveedorService.class);

    @Override
    public boolean insertaProveedor(Proveedor proveedor, String ruta) throws RefaccionariaException {
        logger.debug("Iniciando inserción de proveedor ");
        boolean seInserto = false;
        try {
            ProveedorPk pk = dao.insert(proveedor);
            if (pk.getId() != null) {
                logger.debug("Se inserto correctamente el proveedor " + pk.getId());
                List<Productos> productos = excelDAO.procesaProductos(ruta);
                if (productos != null && !productos.isEmpty()) {
                    logger.debug("Insertando lista de productos");
                    prodDAO.insertaBatch(productos, pk.getId());
                    logger.debug("InsertandO ARCHIVOS");
                    //daoArchivo.insert(ruta, pk.getId());
                }
                seInserto = true;
            }
        } catch (Exception e) {
            logger.error("Error al realizar la inserción " + e.getMessage(), e);
        }
        return seInserto;
    }

    @Override
    public ComboModelProveedor obtieneModelProveedor() throws RefaccionariaException {
        ComboModelProveedor model = null;
        try {
            logger.debug("Obteniendo modelo de datos para proveedores");
            List<Proveedor> proveedores = dao.findAll();
            model = new ComboModelProveedor(proveedores);
        } catch (ProveedorDaoException ex) {
            logger.error("Error al obetner la lista de proveedores " + ex.getMessage(), ex);
        }
        return model;
    }

    @Override
    public boolean actualizaCatalogo(String proveedor, String ruta) throws RefaccionariaException {
        logger.debug("Iniciando actualización del catalogo de proveedor " + proveedor);
        boolean seInserto = false;
        try {
            List<Proveedor> proveedores = dao.findWhereEmpresaEquals(proveedor);            
            if (proveedores != null && !proveedores.isEmpty()) {
                logger.debug("Obteniendo productos ");
                List<Productos> productos = excelDAO.procesaProductos(ruta);
                logger.debug("Iniciando actualización de catalogo ");
                if (productos != null && !productos.isEmpty()) {
                    logger.debug("Borrando catalogo anterior ");
                    if(prodDAO.deleteIdProveedor(proveedores.get(0).getId())) {                        
                        logger.debug("Actualizando catalogo ");
                        logger.debug("Insertando lista de productos");
                        prodDAO.insertaBatch(productos, proveedores.get(0).getId());
                        logger.debug("Termino con éxito ");
                        seInserto = true;
                    }
                }
                
            }
        } catch (Exception e) {
            logger.error("Error al realizar la inserción " + e.getMessage(), e);
        }
        return seInserto;
    }
}
