/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.amickom.service;

import com.amickom.autopartdao.dto.Proveedor;
import com.amickom.service.exception.RefaccionariaException;
import com.amickom.service.util.ComboModelProveedor;

/**
 *
 * @author GRUPO HERA HP2
 */
public interface IProveedorService {

    /**
     * Realiza el alta de un proveedor
     * @param proveedor proveedor que va a ser dado de alta
     * @param ruta ruta del catalogo de productos
     * @return true en caso de ser  correcto, false en caso contrario
     * @throws RefaccionariaException en caso de cualquier excepción 
     */
    public boolean insertaProveedor(Proveedor proveedor, String ruta) throws RefaccionariaException;

    /**
     * Obtiene el modelo de proveedores para el combobox
     * @return ComboModelProveedor modelo de datos para el combobox de proveedores
     * @throws RefaccionariaException  en caso de cualquier excepción
     */
    public ComboModelProveedor obtieneModelProveedor() throws RefaccionariaException;
    
    /**
     * Actualiza el catalogo de productos de acuerdo al proveedor
     * @param proveedor proveedor del que se actualizaran los catalogos
     * @param ruta ruta del nuevo catalogo
     * @return true si se actualizó bien false en caso contrario
     * @throws RefaccionariaException en caso de cualquier excepción 
     */
    public boolean actualizaCatalogo(String proveedor, String ruta) throws RefaccionariaException;
}
